var name, password, taken, error ;

function signup() {
	name = document.getElementById("name").value;
	password = document.getElementById("password").value;
	confrim = document.getElementById("confrim").value
	error = "Your data is incorrect ";
 done = "You have successfully registered"
	if (name === "" ) {
		document.getElementById("results").innerHTML = error;
	} else if (password === ""){
		document.getElementById("results").innerHTML = error;
	}
	else if (confrim === ""){
		document.getElementById("results").innerHTML = error;
	}
	else if (confrim != password){
		document.getElementById("results").innerHTML = error;
	}
	 else {
		document.getElementById("results").innerHTML = done;
	}
}
